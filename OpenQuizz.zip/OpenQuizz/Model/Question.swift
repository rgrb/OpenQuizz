//
//  question.swift
//  OpenQuizz
//
//  Created by rgrb on 10/01/2019.
//  Copyright © 2019 rgrb. All rights reserved.
//

import Foundation

struct Question {
    var title = ""
    var isCorrect = false
}
